package com.xm.store.mapper;


import com.xm.store.dao.UserMapper;
import com.xm.store.pojo.User;
import com.xm.store.service.Impl.UserServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UserMaperTest {
    @Autowired
    private UserServiceImpl userService;
    @Test
    public void insert(){
        User user = new User();
        user.setUsername("asc");
        user.setPassword("123");
        userService.reg(user);
    }
}
