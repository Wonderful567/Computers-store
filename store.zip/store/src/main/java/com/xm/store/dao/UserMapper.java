package com.xm.store.dao;

import com.xm.store.pojo.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    public int insert(User user);
    public User findByUsername(String username);
}
