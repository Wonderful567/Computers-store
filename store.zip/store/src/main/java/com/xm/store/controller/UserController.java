package com.xm.store.controller;


import com.xm.store.pojo.User;
import com.xm.store.service.IUserService;
import com.xm.store.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("users")
public class UserController extends BaseController {
    @Autowired
    private IUserService userServiceImpl;
    @RequestMapping("log")
    public JsonResult<Void> reg(User user){
        userServiceImpl.reg(user);
        return new JsonResult<Void>(OK);
    }
}
