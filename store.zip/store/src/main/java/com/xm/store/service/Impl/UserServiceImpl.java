package com.xm.store.service.Impl;

import com.xm.store.dao.UserMapper;
import com.xm.store.pojo.User;
import com.xm.store.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.xml.crypto.Data;
import java.util.Date;
import java.util.UUID;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    UserMapper userMapper;
    @Override
    public void reg(User user) {
        String username = user.getUsername();
        if(userMapper.findByUsername(username)!=null){
            throw new SecurityException("该用户名已存在，请尝试其他的");
        }
        Date nowTime = new Date();
        String salt = UUID.randomUUID().toString().toUpperCase();
        String md5Password = getMd5Password(user.getPassword(), salt);
        user.setPassword(md5Password);
        // 补全数据：盐值
        user.setSalt(salt);
        // 补全数据：isDelete(0)
        user.setIs_delete(0);
        // 补全数据：4项日志属性
        user.setCreated_user(username);
        user.setCreated_time(nowTime);
        user.setModified_user(username);
        user.setModified_time(nowTime);

        userMapper.insert(user);
    }

    private String getMd5Password(String password, String salt) {
        /*
         * 加密规则：
         * 1、无视原始密码的强度
         * 2、使用UUID作为盐值，在原始密码的左右两侧拼接
         * 3、循环加密3次
         */
        for (int i = 0; i < 3; i++) {
            password = DigestUtils.md5DigestAsHex((salt + password + salt).getBytes()).toUpperCase();
        }
        return password;
    }
}
