package com.xm.store.service;

import com.xm.store.pojo.User;

public interface IUserService {
    public void reg(User user);
}
