package com.xm.store.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User extends BasePojo{
    private int uid;
    private String username;
    private String password;
    private String salt;
    private String phone;
    private String email;
    private int gender;
    private String avatar;
    private int is_delete;
}
